# Wiring viewer — phase 2 handover

Unzip at the repo root. **Contains only the files changed this round** — five
pipeline scripts and `schema/schema.sql`. Nothing else is touched, so nothing
the code session has already fixed gets reverted.

## The idea

The 1978 Australian master sheet prints every wire number at **both** ends of
its wire. So connectivity does not have to be traced — it falls out of
transcription, and *"does every number appear exactly twice"* is a free,
continuous correctness check that runs while you work.

Phase 2 builds that loop:

```
  wiring.html?edit=1   box components, record wire ends, tag circuits
        ↓  Export edits  (JSON snapshot of one sheet)
  apply_wiring_edits.py → fiat.db
        ↓
  derive_wires.py      pair ends by number → wd_wire; report what didn't pair
        ↓
  export_wiring.py     → the site, wires visible and clickable
```

## New files

| file | what it does |
|---|---|
| `pipeline/apply_wiring_edits.py` | Loads an editor export into `fiat.db`. The export is a **snapshot of one sheet**, so applying is a scoped replace — idempotent, and nothing outside that sheet moves. |
| `pipeline/derive_wires.py` | Pairs wire ends sharing a number into `wd_wire` rows. Refuses to guess: unpaired, over-paired and colour-disagreeing numbers are **reported as a worklist**, never invented into wires. |
| `pipeline/propose_wire_ends.py` | OCRs a sheet and proposes wire ends for the editor to review. See the honest numbers below. |

## Changed files

| file | change |
|---|---|
| `pipeline/export_wiring.py` | The editor (`?edit=1`), circuit focus mode, derived-wire connectors, wire ends in the payload, publishes OCR proposals. |
| `pipeline/ingest_wiring.py` | Adds the `wd_wire_end` DDL. **Also carries the credit fix** from `wiring-credit-cleanup.zip` — if that hasn't been run yet, this supersedes it (the `source.notes` SQL is still in the prompt, and is safe to re-run). |
| `schema/schema.sql` | Mirrors `wd_wire_end`. |

## The editor

Open any sheet with `?edit=1`. Keys: **1** select, **2** component, **3** wire
end, **Delete** removes the selection.

- **Component** — drag a box over a numbered callout, fill in the number, name,
  where it sits on the car.
- **Wire end** — click a wire stub, enter its number and colour code, optionally
  the component and terminal, and tag it with circuits.
- **Pairing check** — live in the side panel. Every number appearing once or 3+
  times is listed and clickable; clicking zooms to it.
- Work is kept in the browser as you go, so a reload costs nothing. **Export
  edits** downloads the snapshot for `apply_wiring_edits.py`.

Markers are drawn at constant *screen* size — on a 6106 px sheet at fit zoom an
image-space hotspot would render about 1.5 px across and be invisible.

## OCR proposals — what they're actually worth

Measured on the pilot sheet, not estimated:

| | |
|---|---|
| tokens read | 1,239 |
| candidate wire numbers | 494 |
| distinct 3-digit numbers | 169 |
| **pairing cleanly (both ends read)** | **55 — about a third** |
| appearing once | 110 |

So proposals are a **starting point, not an answer**: they save typing on the
ends they do find and they cost review time on the ones they get wrong. They
load dashed and unconfirmed, and they never touch `fiat.db` directly. A useful
side finding: about **90 distinct one- and two-digit numbers** were read, which
lines up well with the ~87 component callouts.

Auto-tracing polylines was dropped, as the plan allowed. On this sheet it would
solve a problem the wire numbers have already solved.

## Not done yet

- Polyline tracing. A wire with no traced path is drawn as a **dashed straight
  run between its two ends** — honest about being connectivity, not routing.
- Cross-links from components to parts plates and manual sections.
- The `ed-manual` fuse table (page 10) still wants transcribing as its own
  US-fuel-injected dataset.
