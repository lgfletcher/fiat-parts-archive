# Wiring viewer — phase 1 handover

Unzip at the repo root (overwrites the listed files, adds the new ones), then
run the commands in `PROMPT.txt`. Everything here is scripts + one static data
file; all images and JSON are regenerated locally by the pipeline.

## New files

| file | what it does |
|---|---|
| `pipeline/ingest_wiring.py` | Renders every wiring PDF to sheet images and registers them in `fiat.db`. Fold-out master sheets at full native resolution, ordinary pages capped at 2400 px. Creates the wiring tables. |
| `pipeline/export_wiring.py` | Builds `docs/wiring.html` + `docs/wiringdata/*.js` + `docs/wiringimg/**`. |
| `pipeline/seed_wiring_meta.py` | Seeds `wd_circuit` with the 20 circuits (descriptions, symptoms, tests) ported from the interactive-wiring prototype. |
| `docs/wiring_ref.js` | Hand-maintained reference data: Fiat colour codes, the gotchas, the Series 1 lettered fuse panel. Not generated — edit it directly. |

## Changed files

| file | change |
|---|---|
| `schema/schema.sql` | v0.3 section: `wiring_diagram`, `wd_sheet`, `wd_circuit`, `wd_component`, `wd_wire`. |
| `pipeline/export_library.py` | Wiring PDFs now get an "open in wiring viewer" chip; header gains a Wiring link. |
| `pipeline/export_docs.py`, `export_site.py`, `export_paint.py` | Header nav links to `wiring.html`. |

## What phase 1 produced

- 5 wiring diagrams, 61 sheets, 10 fold-out master sheets.
- The pilot sheet (1978 Australian, p.18, 6106 × 3222 px) is fully legible at 1:1
  — wire colour codes and wire numbers read cleanly.
- Total added to `docs/`: about 18 MB of WebP for the wiring layer, plus about
  17 MB of page images for the Electrical Diagnostic Manual. `docs/` goes from
  185 MB to 221 MB.
- The Electrical Diagnostic Manual (74 pages) is ingested through the existing
  document pipeline and is live at `doc.html?d=ed-manual`.

## Notes for later

- `docs/` at 221 MB moves the R2 migration up the queue.
- `Bertone_X19_1988_owners_manual.pdf` in `archive/raw/x19/` is 134 bytes —
  looks like a failed/pointer file, worth re-fetching.
