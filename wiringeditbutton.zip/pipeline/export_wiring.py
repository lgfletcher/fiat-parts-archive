#!/usr/bin/env python3
"""
Export wiring diagrams to the static site (phase 1: the raster layer).

    python3 pipeline/export_wiring.py --db fiat.db \
        --sheets archive/derived/wiring --out docs

Produces:
    docs/wiring.html                  the wiring viewer (one file, all diagrams)
    docs/wiringdata/<slug>.js         sheets + overlay payload for one diagram
    docs/wiringimg/<slug>/sNN.webp    sheet images
    docs/wiring_index.js              list of wiring diagrams

The overlay arrays (components / wires / circuits) are exported here too. They
are empty until the phase-2 editor fills wd_component / wd_wire / wd_circuit,
but the viewer already draws whatever is in them, so tracing work shows up on
the site the moment it lands in fiat.db.

docs/wiring_ref.js (colour codes, fuse lore) is hand-maintained, not generated.
"""
import argparse, json, shutil, sqlite3
from pathlib import Path


# Kept here as well as in ingest_wiring.py so the exporter works against a
# database created before phase 2 existed.
WIRE_END_DDL = """
CREATE TABLE IF NOT EXISTS wd_wire_end (
    id             INTEGER PRIMARY KEY,
    sheet_id       INTEGER NOT NULL REFERENCES wd_sheet(id),
    wire_no        TEXT NOT NULL,
    colour_code    TEXT,
    component_code TEXT,
    pin            TEXT,
    circuit_ids    TEXT,                  -- comma-separated wd_circuit.code
    x REAL, y REAL,
    src            TEXT DEFAULT 'manual' CHECK (src IN ('manual','ocr')),
    conf           TEXT DEFAULT 'unknown'
                   CHECK (conf IN ('verified','typical','unknown')),
    verified       INTEGER DEFAULT 0,
    notes          TEXT
);
CREATE INDEX IF NOT EXISTS idx_wd_end_sheet ON wd_wire_end(sheet_id);
CREATE INDEX IF NOT EXISTS idx_wd_end_no    ON wd_wire_end(sheet_id, wire_no);
"""


def fetch_overlay(db, diagram_id, sheet_ids):
    """Components / wires / circuits for one diagram, keyed by sheet number."""
    comps, wires = [], []
    for sheet_no, sid in sheet_ids.items():
        for c in db.execute("""SELECT code,name,name_en,x,y,w,h,location_on_car,
                                      terminals,part_no,notes,conf,verified
                               FROM wd_component WHERE sheet_id=? ORDER BY code""", (sid,)):
            comps.append({"s": sheet_no, "code": c["code"], "name": c["name"],
                          "en": c["name_en"], "x": c["x"], "y": c["y"],
                          "w": c["w"], "h": c["h"], "loc": c["location_on_car"],
                          "pins": json.loads(c["terminals"]) if c["terminals"] else [],
                          "pn": c["part_no"], "notes": c["notes"],
                          "conf": c["conf"], "v": c["verified"]})
        for w in db.execute("""SELECT label,colour_code,gauge,from_component,from_pin,
                                      to_component,to_pin,path,circuit_ids,conf,
                                      verified,notes
                               FROM wd_wire WHERE sheet_id=? ORDER BY id""", (sid,)):
            wires.append({"s": sheet_no, "label": w["label"], "col": w["colour_code"],
                          "gauge": w["gauge"], "from": w["from_component"],
                          "fpin": w["from_pin"], "to": w["to_component"],
                          "tpin": w["to_pin"],
                          "path": json.loads(w["path"]) if w["path"] else [],
                          "circuits": [x for x in (w["circuit_ids"] or "").split(",") if x],
                          "conf": w["conf"], "v": w["verified"], "notes": w["notes"]})
    ends = []
    for sheet_no, sid in sheet_ids.items():
        for e in db.execute("""SELECT wire_no,colour_code,component_code,pin,
                                      circuit_ids,x,y,src,conf,verified,notes
                               FROM wd_wire_end WHERE sheet_id=?
                               ORDER BY wire_no,y""", (sid,)):
            ends.append({"s": sheet_no, "no": e["wire_no"], "col": e["colour_code"],
                         "comp": e["component_code"], "pin": e["pin"],
                         "circuits": [c for c in (e["circuit_ids"] or "").split(",") if c],
                         "x": e["x"], "y": e["y"], "src": e["src"],
                         "conf": e["conf"], "v": e["verified"], "notes": e["notes"]})
    circuits = [{"code": c["code"], "name": c["name"], "grp": c["grp"],
                 "desc": c["descr"],
                 "symptoms": [s for s in (c["symptoms"] or "").split("\n") if s],
                 "tests": [t for t in (c["tests"] or "").split("\n") if t],
                 "conf": c["conf"]}
                for c in db.execute("""SELECT code,name,grp,descr,symptoms,tests,conf
                                       FROM wd_circuit WHERE diagram_id=?
                                       ORDER BY grp,name""", (diagram_id,))]
    return comps, wires, circuits, ends


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--db", default="fiat.db")
    ap.add_argument("--sheets", default="archive/derived/wiring")
    ap.add_argument("--out", default="docs")
    ap.add_argument("--proposals", default="archive/derived/wiring/proposals",
                    help="OCR wire-end proposals to publish for the editor")
    args = ap.parse_args()

    out = Path(args.out)
    (out / "wiringdata").mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(args.db)
    db.row_factory = sqlite3.Row
    db.executescript(WIRE_END_DDL)      # no-op once ingest_wiring.py has run
    cols = {r[1] for r in db.execute("PRAGMA table_info(wd_wire_end)")}
    if "circuit_ids" not in cols:        # table predates circuit tagging
        db.execute("ALTER TABLE wd_wire_end ADD COLUMN circuit_ids TEXT")
        db.commit()

    index = []
    for d in db.execute("""SELECT id,slug,title,year_from,year_to,market,variant_note,
                                  credit,pilot,notes
                           FROM wiring_diagram ORDER BY sort_order, slug"""):
        rows = db.execute("""SELECT id,sheet_no,kind,label,file_path,width_px,height_px,
                                    native_w,native_h,ocr_text
                             FROM wd_sheet WHERE diagram_id=? ORDER BY sheet_no""",
                          (d["id"],)).fetchall()
        if not rows:
            print(f"  {d['slug']}: no sheets — skipped")
            continue

        imgdir = out / "wiringimg" / d["slug"]
        imgdir.mkdir(parents=True, exist_ok=True)
        sheets, sheet_ids = [], {}
        for r in rows:
            src = Path(args.sheets) / r["file_path"]
            dst = imgdir / Path(r["file_path"]).name
            if src.exists() and (not dst.exists()
                                 or src.stat().st_mtime > dst.stat().st_mtime):
                shutil.copy2(src, dst)
            sheet_ids[r["sheet_no"]] = r["id"]
            sheets.append({"n": r["sheet_no"], "kind": r["kind"], "label": r["label"],
                           "img": f"wiringimg/{d['slug']}/{Path(r['file_path']).name}",
                           "w": r["width_px"], "h": r["height_px"],
                           "nw": r["native_w"], "nh": r["native_h"],
                           "txt": (r["ocr_text"] or "")[:6000]})

        comps, wires, circuits, ends = fetch_overlay(db, d["id"], sheet_ids)
        payload = {"slug": d["slug"], "title": d["title"],
                   "years": [d["year_from"], d["year_to"]], "market": d["market"],
                   "variant": d["variant_note"],
                   "pilot": bool(d["pilot"]), "notes": d["notes"],
                   "sheets": sheets, "components": comps, "wires": wires,
                   "circuits": circuits, "ends": ends}
        (out / "wiringdata" / f"{d['slug']}.js").write_text(
            "window.WIRINGDATA=window.WIRINGDATA||{};window.WIRINGDATA["
            + json.dumps(d["slug"]) + "]=" + json.dumps(payload) + ";")

        index.append({"slug": d["slug"], "title": d["title"],
                      "years": [d["year_from"], d["year_to"]], "market": d["market"],
                      "pilot": bool(d["pilot"]), "nsheets": len(sheets),
                      "nmaster": sum(1 for s in sheets if s["kind"] == "master"),
                      "traced": len(wires)})
        print(f"exported {d['slug']}: {len(sheets)} sheets, "
              f"{len(comps)} components, {len(wires)} wires, {len(ends)} wire ends")

    # OCR proposals are an editor input, not site content: they are unconfirmed
    # by definition and the viewer never draws them unless someone asks.
    prop_src = Path(args.proposals)
    if prop_src.is_dir():
        prop_dst = out / "wiringproposals"
        prop_dst.mkdir(parents=True, exist_ok=True)
        n = 0
        for f in sorted(prop_src.glob("*.json")):
            shutil.copy2(f, prop_dst / f.name); n += 1
        if n:
            print(f"published {n} OCR proposal file(s) for the editor")

    (out / "wiring_index.js").write_text("window.WIRING_INDEX=" + json.dumps(index) + ";")
    (out / "wiring.html").write_text(TEMPLATE)
    print(f"wiring_index: {len(index)} diagrams")


TEMPLATE = r"""<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Wiring diagrams — Fiat Classic Parts Archive</title>
<style>
 :root{--bg:#1c1f26;--panel:#252932;--panel2:#2c313c;--line:#3a4150;--txt:#e8e6df;
   --dim:#9aa0ac;--accent:#e8b84b;--accent2:#7fb4d8;--ok:#8fc98f}
 *{box-sizing:border-box;margin:0;padding:0}html,body{height:100%}
 body{font-family:"Avenir Next","Segoe UI",system-ui,sans-serif;background:var(--bg);
   color:var(--txt);display:flex;flex-direction:column;overflow:hidden}
 header{display:flex;align-items:center;gap:12px;padding:10px 18px;background:var(--panel);
   border-bottom:1px solid var(--line);flex-wrap:wrap}
 h1{font-size:14px;font-weight:600;letter-spacing:.03em;white-space:nowrap;overflow:hidden;
   text-overflow:ellipsis;max-width:38vw}
 header a{color:var(--accent);text-decoration:none;font-size:12.5px;border:1px solid var(--line);
   border-radius:6px;padding:5px 10px;white-space:nowrap}
 .pgnav{display:flex;gap:6px;align-items:center}
 .pgnav button{background:var(--panel2);color:var(--txt);border:1px solid var(--line);
   border-radius:6px;padding:5px 12px;cursor:pointer}
 .pgnav .of{color:var(--dim);font-size:12px;white-space:nowrap}
 .ebtn{background:var(--panel2);color:var(--dim);border:1px solid var(--line);border-radius:6px;
   padding:5px 12px;font-size:12.5px;cursor:pointer;white-space:nowrap}
 .ebtn.on{background:var(--accent);color:#1c1f26;border-color:var(--accent);font-weight:600}
 #q{margin-left:auto;background:var(--panel2);border:1px solid var(--line);color:var(--txt);
   border-radius:6px;padding:6px 12px;font-size:13px;width:230px}
 #app{display:flex;flex:1;min-height:0}
 nav#sheets{width:250px;background:var(--panel);border-right:1px solid var(--line);
   overflow-y:auto;padding:6px 0 30px}
 #sheets .blk{padding:10px 14px 4px;font-size:10.5px;letter-spacing:.12em;color:var(--dim);
   text-transform:uppercase}
 #sheets .dg{padding:7px 14px;font-size:12.5px;cursor:pointer;display:flex;
   justify-content:space-between;gap:8px;align-items:baseline}
 #sheets .dg:hover{background:var(--panel2)}
 #sheets .dg.active{background:var(--panel2);color:var(--accent);border-left:3px solid var(--accent);
   padding-left:11px}
 #sheets .dg .meta{color:var(--dim);font-size:10.5px;white-space:nowrap}
 #sheets .sh{padding:5px 14px 5px 24px;font-size:11.8px;color:var(--dim);cursor:pointer;
   display:flex;justify-content:space-between;gap:6px}
 #sheets .sh:hover{color:var(--txt)}
 #sheets .sh.active{color:var(--accent)}
 #sheets .sh .kd{font-size:9.5px;letter-spacing:.06em;text-transform:uppercase;
   border:1px solid var(--line);border-radius:4px;padding:0 5px;white-space:nowrap}
 #sheets .sh .kd.master{border-color:var(--accent);color:var(--accent)}
 #viewer{flex:1;position:relative;overflow:hidden;background:#14161b;cursor:grab}
 #viewer.dragging{cursor:grabbing}
 #stage{position:absolute;top:0;left:0;transform-origin:0 0}
 #stage img{display:block;background:#fff;box-shadow:0 6px 30px rgba(0,0,0,.5)}
 #ovl{position:absolute;top:0;left:0;overflow:visible}
 .zoomctl{position:absolute;right:14px;top:14px;display:flex;flex-direction:column;gap:6px;z-index:5}
 .zoomctl button{width:34px;height:34px;border-radius:6px;border:1px solid var(--line);
   background:var(--panel);color:var(--txt);font-size:16px;cursor:pointer}
 #layers{position:absolute;left:14px;bottom:14px;z-index:5;background:rgba(37,41,50,.94);
   border:1px solid var(--line);border-radius:8px;padding:10px 12px;font-size:11.5px;
   color:var(--dim);min-width:210px}
 #layers .row{display:flex;align-items:center;gap:8px;margin-bottom:6px}
 #layers .row:last-child{margin-bottom:0}
 #layers label{flex:1;color:var(--txt);font-size:11.5px}
 #layers input[type=range]{width:88px;accent-color:var(--accent)}
 #layers .hint{color:var(--dim);font-size:10.5px;line-height:1.45;margin-top:6px;
   border-top:1px solid var(--line);padding-top:6px}
 aside{width:340px;background:var(--panel);border-left:1px solid var(--line);display:flex;
   flex-direction:column;min-height:0}
 .tabs{display:flex;border-bottom:1px solid var(--line);padding:0 4px}
 .tab{flex:1;background:none;border:0;border-bottom:2px solid transparent;color:var(--dim);
   padding:9px 2px;cursor:pointer;font-size:11.5px;letter-spacing:.03em}
 .tab.on{color:var(--accent);border-bottom-color:var(--accent)}
 #panel{flex:1;overflow-y:auto;padding:0 0 40px}
 .sec{padding:13px 16px;border-bottom:1px solid var(--line)}
 .sec h3{font-size:10.5px;text-transform:uppercase;letter-spacing:.09em;color:var(--dim);
   margin-bottom:8px;font-weight:600}
 .sec p{font-size:12.8px;color:var(--dim);line-height:1.6}
 table.kv{width:100%;border-collapse:collapse;font-size:12.5px}
 table.kv td{padding:4px 0;vertical-align:top;color:var(--txt)}
 table.kv td:first-child{width:104px;color:var(--dim);padding-right:10px}
 table.ctab{width:100%;border-collapse:collapse;font-size:12.5px}
 table.ctab td{padding:5px 6px;border-bottom:1px solid var(--line)}
 td.cit{color:var(--dim);font-style:italic;width:78px}
 .sw{display:inline-flex;align-items:center;justify-content:center;min-width:34px;height:23px;
   border-radius:5px;font-size:11px;font-weight:700;font-family:ui-monospace,monospace;
   border:1px solid rgba(255,255,255,.18);letter-spacing:.03em}
 .sw-unknown{background:repeating-linear-gradient(45deg,#2a323d 0 5px,#222932 5px 10px);color:var(--dim)}
 .note{font-size:12.2px;color:var(--dim);line-height:1.55;padding:8px 10px;background:#20242c;
   border-left:2px solid var(--line);border-radius:0 6px 6px 0;margin-bottom:6px}
 .note.warn{border-left-color:var(--accent)}
 .fusegrid{display:grid;grid-template-columns:repeat(3,1fr);gap:7px}
 .fuse{background:var(--panel2);border:1px solid var(--line);border-radius:8px;padding:10px 4px;
   color:var(--txt);position:relative;overflow:hidden;text-align:center}
 .fuse:before{content:"";position:absolute;inset:0 0 auto 0;height:3px}
 .fuse.f-v:before{background:var(--ok)}.fuse.f-t:before{background:var(--accent)}
 .fuse.f-u:before{background:#4b5462}
 .fuse .fl{font-size:18px;font-weight:700;font-family:ui-monospace,monospace}
 .fuse .fa{font-size:10.5px;color:var(--dim);margin-top:2px}
 .hit{padding:8px 16px;border-bottom:1px solid #2e3340;font-size:12.5px;cursor:pointer}
 .hit:hover{background:var(--panel2)}
 .hit .pno{color:var(--accent);font-weight:600}
 .hit .snip{color:var(--dim);font-size:11.5px;margin-top:2px}
 .hit .snip b{color:var(--accent2);font-weight:600}
 .none{padding:14px 16px;color:var(--dim);font-size:12.5px;line-height:1.6}
 .badge{display:inline-block;font-size:9.5px;text-transform:uppercase;letter-spacing:.08em;
   padding:2px 7px;border-radius:20px;font-weight:700}
 .b-pilot{background:rgba(232,184,75,.16);color:var(--accent)}
 .b-verified{background:rgba(143,201,143,.16);color:var(--ok)}
 .b-typical{background:rgba(232,184,75,.16);color:var(--accent)}
 .b-unknown{background:rgba(120,132,148,.18);color:var(--dim)}
 .credit{padding:10px 16px;font-size:11px;color:var(--dim);border-top:1px solid var(--line)}
 .credit a{color:var(--accent2)}
 /* overlay elements — phase 2 fills these in */
 .wire-hit{fill:none;stroke:transparent;stroke-width:18;cursor:pointer}
 .wire-line{fill:none;stroke-linejoin:round;stroke-linecap:round;pointer-events:none;
   vector-effect:non-scaling-stroke}
 .wire.dim{opacity:.12}
 .wire-line.derived{stroke-dasharray:9 7;opacity:.75}
 .wire.sel .wire-line{stroke-width:7}
 .comp rect{fill:rgba(232,184,75,.08);stroke:var(--accent);stroke-width:2;cursor:pointer;
   vector-effect:non-scaling-stroke}
 .comp.dim{opacity:.12}
 .comp.sel rect{fill:rgba(232,184,75,.24);stroke-width:3.5}
 .comp text{font-size:13px;fill:var(--accent);pointer-events:none;font-weight:600}
 /* wire ends — the transcription unit */
 .end circle{fill:rgba(127,180,216,.25);stroke:var(--accent2);stroke-width:1.5;cursor:pointer;
   vector-effect:non-scaling-stroke}
 .end.ocr circle{stroke-dasharray:3 2}
 .end.bad circle{stroke:#e5484d;fill:rgba(229,72,77,.2)}
 .end.sel circle{stroke-width:3.5;fill:rgba(232,184,75,.35);stroke:var(--accent)}
 .end text{font-size:11px;fill:var(--accent2);pointer-events:none}
 .end.dim,.comp.dim,.wire.dim{opacity:.12}
 #ovl.editing .end circle{cursor:pointer}
 #band{fill:rgba(232,184,75,.12);stroke:var(--accent);stroke-width:2;stroke-dasharray:5 4;
   vector-effect:non-scaling-stroke}
 /* edit toolbar */
 #tools{position:absolute;left:14px;top:14px;z-index:6;display:none;gap:6px;
   background:rgba(37,41,50,.95);border:1px solid var(--line);border-radius:8px;padding:6px}
 #tools.on{display:flex}
 #tools button{background:var(--panel2);color:var(--txt);border:1px solid var(--line);
   border-radius:6px;padding:5px 10px;font-size:12px;cursor:pointer}
 #tools button.on{background:var(--accent);color:#1c1f26;border-color:var(--accent);font-weight:600}
 #tools .sep{width:1px;background:var(--line);margin:0 2px}
 .ebar{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}
 .ebar button{background:var(--panel2);color:var(--txt);border:1px solid var(--line);
   border-radius:6px;padding:5px 10px;font-size:12px;cursor:pointer}
 .ebar button.primary{background:var(--accent);color:#1c1f26;border-color:var(--accent);font-weight:600}
 .frm label{display:block;font-size:10.5px;letter-spacing:.08em;text-transform:uppercase;
   color:var(--dim);margin:8px 0 3px}
 .frm input,.frm select,.frm textarea{width:100%;background:var(--panel2);color:var(--txt);
   border:1px solid var(--line);border-radius:6px;padding:6px 8px;font-size:12.5px;font-family:inherit}
 .frm .two{display:flex;gap:8px}.frm .two>div{flex:1}
 .stat{display:flex;justify-content:space-between;font-size:12.5px;padding:3px 0}
 .stat b{font-family:ui-monospace,monospace}
 .stat.good b{color:var(--ok)}.stat.bad b{color:#e5484d}
 .prob{padding:5px 8px;margin:3px 0;background:#20242c;border-left:2px solid #e5484d;
   border-radius:0 5px 5px 0;font-size:12px;cursor:pointer}
 .prob:hover{background:var(--panel2)}
 .prob b{font-family:ui-monospace,monospace;color:var(--accent)}
</style></head><body>
<header>
  <a href="library.html">← Library</a><a href="index.html">Parts viewer</a>
  <h1 id="title">…</h1>
  <div class="pgnav">
    <button id="prev">‹</button>
    <span class="of" id="of">sheet ? / ?</span>
    <button id="next">›</button>
  </div>
  <button class="ebtn" id="ed-toggle" title="Toggle edit mode">&#9998; Edit</button>
  <button class="ebtn" id="ed-export" style="display:none"
          title="Download this sheet's transcription as JSON">&#11015; Export edits</button>
  <input id="q" type="search" placeholder="Search text on these sheets…" autocomplete="off">
</header>
<div id="app">
  <nav id="sheets"></nav>
  <div id="viewer">
    <div class="zoomctl"><button id="z-in">+</button><button id="z-out">−</button>
      <button id="z-fit" style="font-size:12px">fit</button></div>
    <div id="stage"><img id="base" alt=""><svg id="ovl"></svg></div>
    <div id="tools">
      <button data-tool="select" class="on">Select</button>
      <button data-tool="comp">+ Component</button>
      <button data-tool="end">+ Wire end</button>
      <span class="sep"></span>
      <button id="t-del">Delete</button>
    </div>
    <div id="layers">
      <div class="row"><label for="baseop">Factory scan</label>
        <input id="baseop" type="range" min="0" max="100" value="100"></div>
      <div class="row"><label for="ovlop">Traced overlay</label>
        <input id="ovlop" type="range" min="0" max="100" value="100"></div>
      <div class="hint" id="ovlhint"></div>
    </div>
  </div>
  <aside>
    <div class="tabs">
      <button class="tab on" data-tab="sheet">Sheet</button>
      <button class="tab" data-tab="circuits">Circuits</button>
      <button class="tab" data-tab="colours">Colours</button>
      <button class="tab" data-tab="fuses">Fuses</button>
      <button class="tab" data-tab="search">Search</button>
      <button class="tab" id="tab-edit" data-tab="edit" style="display:none">Edit</button>
    </div>
    <div id="panel"></div>
  </aside>
</div>
<script src="wiring_index.js"></script>
<script src="wiring_ref.js"></script>
<script>
const params=new URLSearchParams(location.search);
const IDX=window.WIRING_INDEX||[];
const pilot=IDX.find(d=>d.pilot)||IDX[0]||{};
let slug=params.get('d')||pilot.slug;
let dg=null,cur=0,tab='sheet',view={x:0,y:0,s:1},sel=null;
const stage=document.getElementById('stage'),viewer=document.getElementById('viewer'),
      base=document.getElementById('base'),ovl=document.getElementById('ovl'),
      panel=document.getElementById('panel');

function load(s,sheetNo){
  slug=s;
  if(window.WIRINGDATA&&window.WIRINGDATA[s]){init(sheetNo);return;}
  const el=document.createElement('script');
  el.src='wiringdata/'+s+'.js';el.onload=()=>init(sheetNo);document.head.appendChild(el);
}
function init(sheetNo){
  dg=window.WIRINGDATA[slug];
  document.getElementById('title').textContent=dg.title;
  document.title=dg.title+' — Fiat Archive';
  buildNav();
  let i=0;
  if(sheetNo){const k=dg.sheets.findIndex(s=>s.n===+sheetNo);if(k>=0)i=k;}
  else {const k=dg.sheets.findIndex(s=>s.kind==='master');if(k>=0)i=k;}
  if(ED)tab='edit';
  show(i);
  syncTabs();
  renderPanel();
}
function buildNav(){
  const nav=document.getElementById('sheets');nav.innerHTML='';
  const b=document.createElement('div');b.className='blk';b.textContent='Wiring diagrams';
  nav.appendChild(b);
  IDX.forEach(d=>{
    const row=document.createElement('div');
    row.className='dg'+(d.slug===slug?' active':'');
    const yrs=d.years[0]===d.years[1]?d.years[0]:d.years[0]+'–'+d.years[1];
    row.innerHTML=`<span>${d.title.replace(/^Wiring diagram — /,'')}`+
      (d.pilot?' <span class="badge b-pilot">pilot</span>':'')+`</span>`+
      `<span class="meta">${d.nsheets} sh</span>`;
    row.title=yrs+' · '+(d.market||'')+' · '+d.nmaster+' fold-out sheet(s)';
    row.onclick=()=>{if(d.slug!==slug)load(d.slug);};
    nav.appendChild(row);
    if(d.slug===slug&&dg){
      dg.sheets.forEach((s,i)=>{
        const e=document.createElement('div');
        e.className='sh'+(i===cur?' active':'');
        e.innerHTML=`<span>${s.label||('Sheet '+s.n)}</span>`+
          (s.kind==='master'?'<span class="kd master">fold-out</span>':'');
        e.onclick=()=>show(i);
        nav.appendChild(e);
      });
    }
  });
}
function show(i){
  if(!dg)return;
  cur=Math.max(0,Math.min(dg.sheets.length-1,i));
  const s=dg.sheets[cur];
  document.getElementById('of').textContent=`sheet ${cur+1} / ${dg.sheets.length}`;
  base.src=s.img;base.width=s.w;base.height=s.h;
  ovl.setAttribute('width',s.w);ovl.setAttribute('height',s.h);
  ovl.setAttribute('viewBox',`0 0 ${s.w} ${s.h}`);
  sel=null;
  if(ED)loadWork();
  drawOverlay();
  fit();
  buildNav();
  if(tab==='sheet')renderPanel();
  // keep edit=1 in the URL: dropping it silently left edit mode on reload
  history.replaceState(null,'','?d='+slug+'&s='+s.n+(ED?'&edit=1':''));
}
/* ---- overlay (empty until phase 2 tracing lands in fiat.db) ---- */
function colourHex(code){
  if(!code||code==='?')return '#7f8896';
  const c=(window.WIRE_COLOURS||{})[code[0]];return c?c.hex:'#7f8896';
}
/* ---------------------------------------------------------------------------
   Overlay rendering. Three kinds of thing live on a sheet:
     component  a named box round a numbered callout
     wire end   one stub: a wire number + colour code at a terminal
     wire       derived by pairing two ends with the same number; may also
                carry a hand-traced polyline
   In edit mode the working copy (W.comps / W.ends) is what gets drawn, so an
   edit shows up immediately without a round trip through the database.
--------------------------------------------------------------------------- */
function sheetComps(){return ED?W.comps:(dg.components||[]).filter(c=>c.s===dg.sheets[cur].n);}
function sheetEnds(){return ED?W.ends:(dg.ends||[]).filter(e=>e.s===dg.sheets[cur].n);}
function inFocus(circuits){return !focusCircuit||(circuits||[]).includes(focusCircuit);}
function endCounts(){
  const c={};sheetEnds().forEach(e=>{const k=(e.no||'').trim();if(k)c[k]=(c[k]||0)+1;});return c;
}
function drawOverlay(){
  const s=dg.sheets[cur];
  ovl.innerHTML='';
  ovl.classList.toggle('editing',ED);
  const wires=(dg.wires||[]).filter(w=>w.s===s.n);
  const comps=sheetComps(), ends=sheetEnds(), counts=endCounts();
  const compCircuits={};
  wires.forEach(w=>{(w.circuits||[]).forEach(cc=>{
    [w.from,w.to].forEach(k=>{if(k){(compCircuits[k]=compCircuits[k]||new Set()).add(cc);}});});});

  // A derived wire has connectivity but no geometry. Rather than leave it
  // invisible, draw a dashed straight run between its two ends: it is honestly
  // not the route the loom takes, and it is dashed to say so, but it makes the
  // netlist visible and clickable the moment it is transcribed.
  const endsByNo={};
  ends.forEach(e=>{const k=(e.no||'').trim();if(k)(endsByNo[k]=endsByNo[k]||[]).push(e);});
  wires.forEach((w,i)=>{
    let segs=w.path||[];
    let derived=false;
    if(!segs.length){
      const g2=endsByNo[(w.label||'').trim()]||[];
      if(g2.length===2){segs=[[[g2[0].x,g2[0].y],[g2[1].x,g2[1].y]]];derived=true;}
    }
    segs.forEach(seg=>{
      if(!seg||seg.length<2)return;
      const d='M'+seg.map(p=>`${(p[0]*s.w).toFixed(1)},${(p[1]*s.h).toFixed(1)}`).join('L');
      const g=mk('g');g.setAttribute('class','wire'+(inFocus(w.circuits)?'':' dim'));
      g.dataset.i=i;
      const hit=mk('path');hit.setAttribute('d',d);hit.setAttribute('class','wire-hit');
      const ln=mk('path');ln.setAttribute('d',d);
      ln.setAttribute('class','wire-line'+(derived?' derived':''));
      ln.setAttribute('stroke',colourHex(w.col));
      ln.setAttribute('stroke-width',w.gauge==='heavy'?7:w.gauge==='med'?5:3.5);
      g.appendChild(hit);g.appendChild(ln);
      g.onclick=e=>{e.stopPropagation();sel={kind:'wire',data:w};tab='sheet';syncTabs();renderPanel();};
      ovl.appendChild(g);
    });
  });

  comps.forEach((c,idx)=>{
    if(c.x==null)return;
    const cf=compCircuits[c.code];
    const g=mk('g');
    g.setAttribute('class','comp'+((!focusCircuit||(cf&&cf.has(focusCircuit)))?'':' dim')
      +(sel&&sel.kind==='comp'&&sel.i===idx?' sel':''));
    const r=mk('rect');
    r.setAttribute('x',c.x*s.w);r.setAttribute('y',c.y*s.h);
    r.setAttribute('width',(c.w||0.02)*s.w);r.setAttribute('height',(c.h||0.02)*s.h);
    r.setAttribute('rx',4);g.appendChild(r);
    if(c.code){const t=mk('text');
      t.setAttribute('x',c.x*s.w);t.setAttribute('y',c.y*s.h);
      t.textContent=c.code;g.appendChild(t);}
    g.onclick=e=>{e.stopPropagation();sel={kind:'comp',data:c,i:idx};
      tab=ED?'edit':'sheet';syncTabs();renderPanel();drawOverlay();};
    ovl.appendChild(g);
  });

  ends.forEach((e,idx)=>{
    if(e.x==null)return;
    const n=(counts[(e.no||'').trim()]||0);
    const g=mk('g');
    g.setAttribute('class','end'+(e.src==='ocr'?' ocr':'')+(n===2?'':' bad')
      +(inFocus(e.circuits)?'':' dim')
      +(sel&&sel.kind==='end'&&sel.i===idx?' sel':''));
    const ci=mk('circle');
    ci.setAttribute('cx',e.x*s.w);ci.setAttribute('cy',e.y*s.h);ci.setAttribute('r',9);
    g.appendChild(ci);
    const t=mk('text');
    t.setAttribute('x',e.x*s.w);t.setAttribute('y',e.y*s.h);
    t.textContent=(e.col?e.col+' ':'')+(e.no||'?');g.appendChild(t);
    g.onclick=ev=>{ev.stopPropagation();sel={kind:'end',data:e,i:idx};
      tab=ED?'edit':'sheet';syncTabs();renderPanel();drawOverlay();};
    ovl.appendChild(g);
  });

  const n=wires.length+comps.length+ends.length;
  const hint=document.getElementById('ovlhint');
  if(ED){
    const paired=Object.values(counts).filter(v=>v===2).length,
          tot=Object.keys(counts).length;
    hint.textContent=`${comps.length} components, ${ends.length} wire ends — `+
      `${paired}/${tot} numbers pair cleanly.`;
  }else{
    hint.textContent = n
      ? `${comps.length} components, ${ends.length} wire ends, ${wires.length} wires on this sheet.`
      : 'Nothing recorded on this sheet yet. Open the editor with ?edit=1 to start.';
  }
  ovl.style.display=(n||ED)?'block':'none';
  rescaleMarkers();
}
/* ---- pan / zoom ---- */
function apply(){
  stage.style.transform=`translate(${view.x}px,${view.y}px) scale(${view.s})`;
  rescaleMarkers();
}
/* A hotspot on a 6106 px sheet viewed at "fit" is about 0.16 scale — a 9 px
   circle would render at 1.5 px and be invisible. Markers are navigation aids,
   so they get a constant SCREEN size; only their positions are in image space. */
function rescaleMarkers(){
  const k=1/Math.max(view.s,0.0001);
  ovl.querySelectorAll('.end circle').forEach(c=>c.setAttribute('r',(7*k).toFixed(2)));
  ovl.querySelectorAll('.end text').forEach(t=>{
    t.setAttribute('font-size',(12*k).toFixed(2));
    t.setAttribute('dx',(11*k).toFixed(2));t.setAttribute('dy',(4*k).toFixed(2));});
  ovl.querySelectorAll('.comp text').forEach(t=>{
    t.setAttribute('font-size',(14*k).toFixed(2));
    t.setAttribute('dy',(-4*k).toFixed(2));});
}
function fit(){const s=dg.sheets[cur],r=viewer.getBoundingClientRect();
  view.s=Math.min(r.width/s.w,r.height/s.h)*.97;
  view.x=(r.width-s.w*view.s)/2;view.y=(r.height-s.h*view.s)/2;apply();}
viewer.addEventListener('wheel',e=>{e.preventDefault();
  const r=viewer.getBoundingClientRect(),mx=e.clientX-r.left,my=e.clientY-r.top;
  const f=e.deltaY<0?1.18:1/1.18,s2=Math.min(14,Math.max(.03,view.s*f));
  view.x=mx-(mx-view.x)*(s2/view.s);view.y=my-(my-view.y)*(s2/view.s);view.s=s2;apply();
},{passive:false});
let drag=null;
viewer.addEventListener('mousedown',e=>{
  if(e.target.closest('.zoomctl')||e.target.closest('#layers'))return;
  drag={mx:e.clientX,my:e.clientY,x:view.x,y:view.y};viewer.classList.add('dragging');});
window.addEventListener('mousemove',e=>{if(!drag)return;
  view.x=drag.x+(e.clientX-drag.mx);view.y=drag.y+(e.clientY-drag.my);apply();});
window.addEventListener('mouseup',()=>{drag=null;viewer.classList.remove('dragging');});
document.getElementById('z-in').onclick=()=>{view.s=Math.min(14,view.s*1.35);apply();};
document.getElementById('z-out').onclick=()=>{view.s=Math.max(.03,view.s/1.35);apply();};
document.getElementById('z-fit').onclick=fit;
window.addEventListener('resize',()=>{if(dg)fit();});
document.getElementById('prev').onclick=()=>show(cur-1);
document.getElementById('next').onclick=()=>show(cur+1);
document.addEventListener('keydown',e=>{
  if(e.target.tagName==='INPUT')return;
  if(e.key==='ArrowLeft')show(cur-1);
  if(e.key==='ArrowRight')show(cur+1);});
document.getElementById('baseop').oninput=e=>{base.style.opacity=e.target.value/100;};
document.getElementById('ovlop').oninput=e=>{ovl.style.opacity=e.target.value/100;};
/* ---- side panel ---- */
function esc(t){return (t||'').replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));}
function swatch(code){
  const C=window.WIRE_COLOURS||{};
  if(!code||code==='?')return '<span class="sw sw-unknown">?</span>';
  const b=C[code[0]],t=code[1]?C[code[1]]:null;
  if(!b)return '<span class="sw sw-unknown">'+esc(code)+'</span>';
  const bg=t?`background:${b.hex};background-image:repeating-linear-gradient(115deg,transparent 0 5px,${t.hex} 5px 9px)`
            :`background:${b.hex}`;
  return `<span class="sw" style="${bg};color:${b.ink}" title="${esc(colourName(code))}">${esc(code)}</span>`;
}
function colourName(code){
  const C=window.WIRE_COLOURS||{};
  if(!code||code==='?')return 'Unknown';
  const b=C[code[0]],t=code[1]?C[code[1]]:null;
  if(!b)return code;
  return t?`${b.en} with ${t.en.toLowerCase()} tracer (${b.it}/${t.it})`:`${b.en} (${b.it})`;
}
function renderPanel(){
  if(!dg){panel.innerHTML='';return;}
  if(tab==='edit')return renderEdit();
  if(tab==='sheet')return renderSheet();
  if(tab==='circuits')return renderCircuits();
  if(tab==='colours')return renderColours();
  if(tab==='fuses')return renderFuses();
  if(tab==='search')return runSearch();
}
function renderSheet(){
  const s=dg.sheets[cur];
  if(sel&&sel.kind==='wire'){
    const w=sel.data;
    panel.innerHTML=`<div class="sec"><h3>Wire</h3>
      <p>${swatch(w.col)} &nbsp; ${esc(colourName(w.col))}</p></div>
      <div class="sec"><table class="kv">
      <tr><td>Function</td><td>${esc(w.label)||'—'}</td></tr>
      <tr><td>Gauge</td><td>${esc(w.gauge)||'—'}</td></tr>
      <tr><td>From</td><td>${esc(w.from)||'—'} ${esc(w.fpin)||''}</td></tr>
      <tr><td>To</td><td>${esc(w.to)||'—'} ${esc(w.tpin)||''}</td></tr>
      <tr><td>Confidence</td><td>${esc(w.conf)}</td></tr></table></div>
      <div class="sec"><p><a href="#" id="clr">← back to sheet details</a></p></div>`;
    document.getElementById('clr').onclick=e=>{e.preventDefault();sel=null;renderPanel();};
    return;
  }
  if(sel&&sel.kind==='comp'){
    const c=sel.data;
    panel.innerHTML=`<div class="sec"><h3>Component ${esc(c.code)}</h3>
      <p>${esc(c.en||c.name||'')}</p></div>
      <div class="sec"><table class="kv">
      <tr><td>On the car</td><td>${esc(c.loc)||'—'}</td></tr>
      <tr><td>Part no.</td><td>${esc(c.pn)||'—'}</td></tr>
      <tr><td>Confidence</td><td>${esc(c.conf)}</td></tr></table></div>
      ${c.notes?`<div class="sec"><h3>Notes</h3><p class="note">${esc(c.notes)}</p></div>`:''}
      <div class="sec"><p><a href="#" id="clr">← back to sheet details</a></p></div>`;
    document.getElementById('clr').onclick=e=>{e.preventDefault();sel=null;renderPanel();};
    return;
  }
  const yrs=dg.years[0]===dg.years[1]?dg.years[0]:dg.years[0]+'–'+dg.years[1];
  panel.innerHTML=`
    <div class="sec"><h3>Diagram</h3><table class="kv">
      <tr><td>Years</td><td>${yrs}</td></tr>
      <tr><td>Market</td><td>${esc(dg.market)||'—'}</td></tr>
      <tr><td>Sheets</td><td>${dg.sheets.length}</td></tr>
    </table>${dg.variant?`<p class="note" style="margin-top:8px">${esc(dg.variant)}</p>`:''}</div>
    <div class="sec"><h3>This sheet</h3><table class="kv">
      <tr><td>Label</td><td>${esc(s.label)||'—'}</td></tr>
      <tr><td>Type</td><td>${s.kind==='master'?'Fold-out schematic':'Page'}</td></tr>
      <tr><td>Image</td><td>${s.w} × ${s.h} px</td></tr>
      <tr><td>Original</td><td>${s.nw} × ${s.nh} px in the PDF</td></tr>
    </table></div>
    <div class="sec"><h3>Overlay</h3><p>${
      (dg.wires||[]).length
        ? `${(dg.wires||[]).length} wires on this diagram, from `+
          `${(dg.ends||[]).length} transcribed wire ends. A dashed run is derived `+
          `from the wire number printed at both ends — it shows what connects to `+
          `what, not the route the loom actually takes.`
        : 'Nothing transcribed on this diagram yet. Open it with <code>?edit=1</code> '+
          'to box components and record wire ends; wires appear as soon as a number '+
          'has been read at both of its ends.'}</p></div>`;
}
function renderCircuits(){
  const cs=dg.circuits||[];
  if(!cs.length){
    panel.innerHTML='<div class="none">No circuit notes recorded for this diagram yet. '+
      'The 1978 Australian sheet carries the seeded set — pick it in the list on the left.</div>';
    return;}
  let h='<div class="sec"><h3>Focus a circuit</h3>'+
    '<select id="f-focus" style="width:100%;background:var(--panel2);color:var(--txt);'+
    'border:1px solid var(--line);border-radius:6px;padding:6px 8px;font-size:12.5px">'+
    '<option value="">— show everything —</option>'+
    cs.map(c=>`<option value="${esc(c.code)}"${focusCircuit===c.code?' selected':''}>`+
      `${esc(c.name)}</option>`).join('')+'</select>'+
    '<p style="margin-top:8px">Dims everything on the sheet that is not part of the '+
    'selected circuit. Takes effect once wires are attached to circuits.</p></div>';
  let lastG=null;
  cs.forEach((c,i)=>{
    if(c.grp!==lastG){lastG=c.grp;h+=`<div class="sec" style="padding-bottom:2px">`+
      `<h3 style="margin:0">${esc(c.grp)}</h3></div>`;}
    h+=`<div class="sec"><div style="display:flex;justify-content:space-between;gap:8px;`+
       `align-items:baseline;cursor:pointer" data-c="${i}">`+
       `<b style="font-size:13px">${esc(c.name)}</b>`+
       `<span class="badge b-${esc(c.conf)}">${esc(c.conf)}</span></div>`+
       `<div class="cbody" id="cb${i}" style="display:none;margin-top:8px">`+
       `<p>${esc(c.desc)}</p>`+
       (c.symptoms.length?'<h3 style="margin-top:10px">Symptoms → likely cause</h3>'+
         c.symptoms.map(s=>`<p class="note">${esc(s)}</p>`).join(''):'')+
       (c.tests.length?'<h3 style="margin-top:10px">How to test</h3>'+
         c.tests.map(t=>`<p class="note warn">${esc(t)}</p>`).join(''):'')+
       `</div></div>`;
  });
  panel.innerHTML=h;
  const fs=document.getElementById('f-focus');
  if(fs)fs.onchange=()=>{focusCircuit=fs.value||null;drawOverlay();};
  panel.querySelectorAll('[data-c]').forEach(e=>{
    e.onclick=()=>{const b=document.getElementById('cb'+e.dataset.c);
      b.style.display=b.style.display==='none'?'block':'none';};});
}
function renderColours(){
  const C=window.WIRE_COLOURS||{};
  let h='<div class="sec"><h3>Fiat / Italian colour codes</h3><table class="ctab">';
  Object.keys(C).forEach(k=>{h+=`<tr><td>${swatch(k)}</td><td class="cit">${esc(C[k].it)}</td>`+
    `<td>${esc(C[k].en)}</td></tr>`;});
  h+='</table></div><div class="sec"><h3>Read these carefully</h3>';
  (window.WIRE_GOTCHAS||[]).forEach(t=>{h+=`<p class="note warn">${esc(t)}</p>`;});
  h+='</div><div class="sec"><h3>Confirmed on the 1978 Australian car</h3>';
  (window.WIRE_KNOWN_COLOURS||[]).forEach(k=>{
    h+=`<p class="note">${swatch(k.code)} <b>${esc(k.circuit)}</b> — ${esc(k.desc)}</p>`;});
  panel.innerHTML=h+'</div>';
}
function renderFuses(){
  const series1=(dg.years[0]||0)<1982;
  let h='';
  if(!series1) h+='<div class="sec"><p class="note warn">This diagram is a Bertone-era '+
    'car, which uses a NUMBERED blade fuse panel. The lettered A–N panel below belongs '+
    'to the Series 1 cars (1974–1982) and does not apply here — read the fuse layout off '+
    'this diagram\'s own fuse-panel sheet.</p></div>';
  h+='<div class="sec"><h3>Series 1 fuse panel (A–N)</h3><div class="fusegrid">';
  (window.WIRE_FUSES||[]).forEach(f=>{
    h+=`<div class="fuse f-${f.conf}" title="${esc(f.feeds)}"><div class="fl">${esc(f.id)}</div>`+
       `<div class="fa">${esc(f.amps)}</div></div>`;});
  h+='</div></div><div class="sec">';
  (window.WIRE_FUSE_NOTES||[]).forEach(t=>{h+=`<p class="note warn">${esc(t)}</p>`;});
  panel.innerHTML=h+'</div>';
}
function runSearch(){
  const term=(document.getElementById('q').value||'').trim().toLowerCase();
  if(term.length<3){
    panel.innerHTML='<div class="none">Type at least 3 characters in the search box. '+
      'Searches the OCR text of every sheet in this diagram — legend pages read well, '+
      'fold-out schematics much less so.</div>';return;}
  const out=[];
  dg.sheets.forEach((s,i)=>{
    const t=(s.txt||'').toLowerCase(),k=t.indexOf(term);
    if(k>=0){
      const raw=s.txt.substring(Math.max(0,k-60),k+term.length+60).replace(/\s+/g,' ');
      out.push({i,n:s.n,snip:esc(raw).replace(
        new RegExp('('+term.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')+')','ig'),'<b>$1</b>')});
    }});
  panel.innerHTML=out.length
    ?out.map(h=>`<div class="hit" data-i="${h.i}"><span class="pno">sheet ${h.n}</span>`+
      `<div class="snip">…${h.snip}…</div></div>`).join('')
    :'<div class="none">No sheets match. OCR on a wiring sheet is rough — try a shorter word.</div>';
  panel.querySelectorAll('.hit').forEach(e=>{e.onclick=()=>{show(+e.dataset.i);};});
}
document.querySelectorAll('.tab').forEach(t=>{
  t.onclick=()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.remove('on'));
    t.classList.add('on');tab=t.dataset.tab;renderPanel();};});
let deb=null;
document.getElementById('q').addEventListener('input',()=>{
  clearTimeout(deb);deb=setTimeout(()=>{
    tab='search';
    document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('on',x.dataset.tab==='search'));
    renderPanel();},250);});
viewer.addEventListener('click',e=>{
  if(e.target===viewer||e.target===base){sel=null;if(tab==='sheet')renderPanel();}});
/* =========================================================================
   EDIT MODE  —  wiring.html?edit=1
   -------------------------------------------------------------------------
   The pilot sheet encodes connectivity numerically: every wire number appears
   at exactly two ends. So the job is not to trace pixels, it is to transcribe
   ends — and "does every number appear exactly twice" is a free, continuous
   correctness check that runs while you work.

   Work in progress is kept in localStorage per (diagram, sheet) so a reload
   never costs you a session. Export writes a JSON snapshot of the whole sheet,
   which pipeline/apply_wiring_edits.py loads into fiat.db.
========================================================================= */
let ED=params.get('edit')==='1';
let tool='select', W={comps:[],ends:[]}, focusCircuit=null;
function mk(t){return document.createElementNS('http://www.w3.org/2000/svg',t);}
function syncTabs(){
  document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('on',x.dataset.tab===tab));
}
function storeKey(){return 'wiring-edit:'+slug+':'+dg.sheets[cur].n;}
function saveWork(){
  try{localStorage.setItem(storeKey(),JSON.stringify(W));}catch(err){/* private mode, quota */}
}
function loadWork(){
  const s=dg.sheets[cur];
  W={comps:(dg.components||[]).filter(c=>c.s===s.n).map(c=>Object.assign({},c)),
     ends:(dg.ends||[]).filter(e=>e.s===s.n).map(e=>Object.assign({},e))};
  try{
    const raw=localStorage.getItem(storeKey());
    if(raw){const o=JSON.parse(raw);
      if(o&&Array.isArray(o.comps)&&Array.isArray(o.ends))W=o;}
  }catch(err){/* ignore a corrupt draft rather than lose the session */}
}
/* screen -> image coordinates, through the stage transform */
function toImg(ev){
  const r=viewer.getBoundingClientRect(),s=dg.sheets[cur];
  return {x:((ev.clientX-r.left)-view.x)/view.s/s.w,
          y:((ev.clientY-r.top )-view.y)/view.s/s.h};
}
/* Edit mode is a toggle in the header, the same gesture as the parts viewer's
   ✎ Edit button — not a URL you have to know to type. The URL still carries
   edit=1 so a session can be bookmarked or shared mid-transcription. */
function setEdit(on){
  ED=on;
  document.getElementById('tools').classList.toggle('on',on);
  document.getElementById('tab-edit').style.display=on?'':'none';
  document.getElementById('ed-toggle').classList.toggle('on',on);
  document.getElementById('ed-export').style.display=on?'':'none';
  if(on){loadWork();tab='edit';}
  else if(tab==='edit'){tab='sheet';}
  sel=null;syncTabs();
  if(dg){
    const s=dg.sheets[cur];
    history.replaceState(null,'','?d='+slug+'&s='+s.n+(on?'&edit=1':''));
    drawOverlay();renderPanel();
  }
}
document.getElementById('ed-toggle').onclick=()=>setEdit(!ED);
document.getElementById('ed-export').onclick=()=>exportEdits();
{
  document.querySelectorAll('#tools [data-tool]').forEach(b=>{
    b.onclick=()=>{tool=b.dataset.tool;
      document.querySelectorAll('#tools [data-tool]').forEach(x=>
        x.classList.toggle('on',x===b));};});
  document.getElementById('t-del').onclick=deleteSelected;
  document.addEventListener('keydown',ev=>{
    if(!ED)return;
    if(ev.target.tagName==='INPUT'||ev.target.tagName==='TEXTAREA')return;
    if(ev.key==='Delete'||ev.key==='Backspace'){ev.preventDefault();deleteSelected();}
    if(ev.key==='1')document.querySelector('[data-tool=select]').click();
    if(ev.key==='2')document.querySelector('[data-tool=comp]').click();
    if(ev.key==='3')document.querySelector('[data-tool=end]').click();
  });
}
function deleteSelected(){
  if(!ED||!sel)return;
  if(sel.kind==='comp')W.comps.splice(sel.i,1);
  else if(sel.kind==='end')W.ends.splice(sel.i,1);
  else return;
  sel=null;saveWork();drawOverlay();renderPanel();
}
/* ---- drawing: component box by drag, wire end by click ---- */
let band=null;
viewer.addEventListener('mousedown',ev=>{
  if(!ED||tool==='select')return;
  if(ev.target.closest('.zoomctl')||ev.target.closest('#layers')||ev.target.closest('#tools'))return;
  ev.stopPropagation();
  const p=toImg(ev);
  if(tool==='end'){
    W.ends.push({no:'',col:'',comp:'',pin:'',circuits:[],
                 x:+p.x.toFixed(6),y:+p.y.toFixed(6),
                 src:'manual',conf:'unknown',v:0});
    sel={kind:'end',data:W.ends[W.ends.length-1],i:W.ends.length-1};
    saveWork();drawOverlay();tab='edit';syncTabs();renderPanel();
    setTimeout(()=>{const f=document.getElementById('f-no');if(f)f.focus();},0);
    return;
  }
  band={x0:p.x,y0:p.y,x1:p.x,y1:p.y};
},true);
window.addEventListener('mousemove',ev=>{
  if(!band)return;
  const p=toImg(ev);band.x1=p.x;band.y1=p.y;
  const s=dg.sheets[cur];
  let r=document.getElementById('band');
  if(!r){r=mk('rect');r.id='band';ovl.appendChild(r);}
  r.setAttribute('x',Math.min(band.x0,band.x1)*s.w);
  r.setAttribute('y',Math.min(band.y0,band.y1)*s.h);
  r.setAttribute('width',Math.abs(band.x1-band.x0)*s.w);
  r.setAttribute('height',Math.abs(band.y1-band.y0)*s.h);
});
window.addEventListener('mouseup',()=>{
  if(!band)return;
  const b=band;band=null;
  const w=Math.abs(b.x1-b.x0),h=Math.abs(b.y1-b.y0);
  if(w<0.001||h<0.001){drawOverlay();return;}   // a stray click, not a box
  W.comps.push({code:'',name:'',en:'',x:+Math.min(b.x0,b.x1).toFixed(6),
                y:+Math.min(b.y0,b.y1).toFixed(6),w:+w.toFixed(6),h:+h.toFixed(6),
                loc:'',notes:'',conf:'unknown',v:0});
  sel={kind:'comp',data:W.comps[W.comps.length-1],i:W.comps.length-1};
  saveWork();drawOverlay();tab='edit';syncTabs();renderPanel();
  setTimeout(()=>{const f=document.getElementById('f-code');if(f)f.focus();},0);
});
/* ---- the Edit panel ---- */
function field(id,label,val,ph){
  return `<label for="${id}">${label}</label>`+
         `<input id="${id}" value="${esc(val||'')}" placeholder="${esc(ph||'')}">`;
}
function renderEdit(){
  const counts=endCounts();
  const distinct=Object.keys(counts), paired=distinct.filter(k=>counts[k]===2);
  const singles=distinct.filter(k=>counts[k]===1).sort();
  const over=distinct.filter(k=>counts[k]>2).sort();
  let h='';
  if(sel&&sel.kind==='comp'){
    const c=sel.data;
    h+=`<div class="sec frm"><h3>Component</h3>
      ${field('f-code','Callout number',c.code,'e.g. 27')}
      ${field('f-name','Name (as printed)',c.name,'')}
      ${field('f-en','Name in English',c.en,'e.g. Turn signal relay')}
      ${field('f-loc','Where on the car',c.loc,'e.g. behind the dash, LH')}
      <label for="f-conf">Confidence</label>
      <select id="f-conf">${['unknown','typical','verified'].map(o=>
        `<option${c.conf===o?' selected':''}>${o}</option>`).join('')}</select>
      <label for="f-notes">Notes</label><textarea id="f-notes" rows="3">${esc(c.notes||'')}</textarea>
      <div class="ebar"><button id="b-del">Delete</button></div></div>`;
  } else if(sel&&sel.kind==='end'){
    const e=sel.data, n=counts[(e.no||'').trim()]||0;
    h+=`<div class="sec frm"><h3>Wire end</h3>
      ${field('f-no','Wire number',e.no,'e.g. 258')}
      ${field('f-col','Colour code',e.col,'e.g. GR')}
      ${field('f-comp','At component',e.comp,'callout number')}
      ${field('f-pin','Terminal / pin',e.pin,'')}
      <label for="f-circ">Circuits this wire belongs to</label>
      <select id="f-circ" multiple size="6">${(dg.circuits||[]).map(c=>
        `<option value="${esc(c.code)}"${(e.circuits||[]).includes(c.code)?' selected':''}>`+
        `${esc(c.name)}</option>`).join('')}</select>
      <div class="stat ${n===2?'good':'bad'}"><span>This number appears</span>
        <b>${n}&times;</b></div>
      ${e.col?`<div class="stat"><span>${esc(colourName(e.col))}</span>
        <span>${swatch(e.col)}</span></div>`:''}
      <div class="ebar"><button id="b-del">Delete</button></div></div>`;
  } else {
    h+=`<div class="sec"><h3>Editing</h3><p>Draw a box over a numbered callout to
      add a component, or click a wire stub to add a wire end. Keys: 1 select,
      2 component, 3 wire end, Delete removes the selection.</p></div>`;
  }
  h+=`<div class="sec"><h3>Pairing check</h3>
    <div class="stat"><span>Components</span><b>${W.comps.length}</b></div>
    <div class="stat"><span>Wire ends</span><b>${W.ends.length}</b></div>
    <div class="stat good"><span>Numbers pairing cleanly</span><b>${paired.length}</b></div>
    <div class="stat ${singles.length?'bad':''}"><span>Appearing once</span><b>${singles.length}</b></div>
    <div class="stat ${over.length?'bad':''}"><span>Appearing 3+ times</span><b>${over.length}</b></div>
    <p style="margin-top:8px">Every wire number is printed at both ends of its wire, so
    anything not appearing exactly twice is an error — a missed end, or a misread digit.</p>`;
  singles.slice(0,40).forEach(k=>{h+=`<div class="prob" data-no="${esc(k)}">
    <b>${esc(k)}</b> — only one end recorded</div>`;});
  over.slice(0,40).forEach(k=>{h+=`<div class="prob" data-no="${esc(k)}">
    <b>${esc(k)}</b> — ${counts[k]} ends recorded</div>`;});
  h+=`</div><div class="sec"><h3>Session</h3>
    <div class="ebar">
      <button id="b-export" class="primary">Export edits</button>
      <button id="b-ocr">Load OCR proposals</button>
      <button id="b-reset">Discard draft</button>
    </div>
    <p style="margin-top:8px">Work is saved in this browser as you go. Export writes a
    JSON snapshot for <code>apply_wiring_edits.py</code>. OCR proposals arrive
    unconfirmed and dashed — they are a starting point, not an answer.</p></div>`;
  panel.innerHTML=h;

  const bind=(id,key,obj)=>{const el=document.getElementById(id);if(!el)return;
    el.oninput=()=>{obj[key]=el.value;saveWork();drawOverlay();};};
  if(sel&&sel.kind==='comp'){
    bind('f-code','code',sel.data);bind('f-name','name',sel.data);
    bind('f-en','en',sel.data);bind('f-loc','loc',sel.data);
    bind('f-notes','notes',sel.data);bind('f-conf','conf',sel.data);
  }
  if(sel&&sel.kind==='end'){
    ['no','col','comp','pin'].forEach(k=>bind('f-'+k,k,sel.data));
    const cs=document.getElementById('f-circ');
    if(cs)cs.onchange=()=>{sel.data.circuits=[...cs.selectedOptions].map(o=>o.value);
      saveWork();drawOverlay();};
    const no=document.getElementById('f-no');
    if(no)no.oninput=()=>{sel.data.no=no.value;sel.data.src='manual';
      saveWork();drawOverlay();renderEdit();};
  }
  const del=document.getElementById('b-del');if(del)del.onclick=deleteSelected;
  panel.querySelectorAll('.prob').forEach(el=>{el.onclick=()=>{
    const k=el.dataset.no;const i=W.ends.findIndex(e=>(e.no||'').trim()===k);
    if(i>=0){sel={kind:'end',data:W.ends[i],i};zoomTo(W.ends[i]);drawOverlay();renderEdit();}};});
  document.getElementById('b-export').onclick=exportEdits;
  document.getElementById('b-ocr').onclick=loadProposals;
  document.getElementById('b-reset').onclick=()=>{
    if(!confirm('Discard this browser draft and go back to what is in the database?'))return;
    try{localStorage.removeItem(storeKey());}catch(err){}
    sel=null;loadWork();drawOverlay();renderEdit();};
}
function zoomTo(e){
  const s=dg.sheets[cur],r=viewer.getBoundingClientRect();
  view.s=Math.max(view.s,1.5);
  view.x=r.width/2-e.x*s.w*view.s;view.y=r.height/2-e.y*s.h*view.s;apply();
}
function exportEdits(){
  const s=dg.sheets[cur];
  const payload={diagram:slug,sheet:s.n,image_w:s.w,image_h:s.h,
    exported_from:'wiring.html',
    components:W.comps,wire_ends:W.ends};
  const blob=new Blob([JSON.stringify(payload,null,1)],{type:'application/json'});
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob);
  a.download=`wiring_edits-${slug}-s${String(s.n).padStart(2,'0')}.json`;
  a.click();URL.revokeObjectURL(a.href);
}
function loadProposals(){
  const s=dg.sheets[cur];
  const url=`wiringproposals/${slug}-s${String(s.n).padStart(2,'0')}.json`;
  fetch(url).then(r=>{if(!r.ok)throw new Error(r.status);return r.json();})
    .then(o=>{
      const have=new Set(W.ends.map(e=>Math.round(e.x*4000)+':'+Math.round(e.y*4000)));
      let added=0;
      (o.ends||[]).forEach(e=>{
        const k=Math.round(e.x*4000)+':'+Math.round(e.y*4000);
        if(have.has(k))return;
        have.add(k);added++;
        W.ends.push({no:e.wire_no||'',col:e.colour||'',comp:'',pin:'',circuits:[],
                     x:e.x,y:e.y,src:'ocr',conf:'unknown',v:0});
      });
      saveWork();drawOverlay();renderEdit();
      alert(`Added ${added} OCR proposals. They are dashed and unconfirmed — `+
            `check each against the print before exporting.`);
    })
    .catch(err=>alert('No proposal file for this sheet ('+url+').\n\n'+
      'Generate one with:\n  python3 pipeline/propose_wire_ends.py --diagram '+slug+
      ' --sheet '+s.n));
}

if(ED){                     // reflect the URL in the chrome before data arrives
  document.getElementById('tools').classList.add('on');
  document.getElementById('tab-edit').style.display='';
  document.getElementById('ed-toggle').classList.add('on');
  document.getElementById('ed-export').style.display='';
}
if(slug)load(slug,params.get('s'));
else document.getElementById('title').textContent='No wiring diagrams ingested yet';
</script></body></html>"""


if __name__ == "__main__":
    main()
